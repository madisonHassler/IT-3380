#query ClassicModels database - November 9, 2021
import mysql.connector

def get_mangers(mycursor):
    #create query
    sql_query = '''SELECT department_name, COUNT(department_name) AS "Number of Managers"
                    FROM managers
                    GROUP BY department_name
                    ORDER BY COUNT(department_name) DESC;'''

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    print("\nManagers per Department\n---------------------")
    #loop through results
    for record in query_result:
        print(f"{record[0]} Department: {record[1]} managers")
    
    return

def get_americas_employees(mycursor):
    print("\nEmployees in the Americas\n---------------------")
    #create query
    sql_query = 'SELECT * FROM EmployeesPerRegion WHERE region_name = "Americas";'

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]}: {record[1]} employees\n")
    
    return
    
def get_department_most_dependents(mycursor):
    print("\nDepartments with the most Dependents\n---------------------")
    #create query
    sql_query = '''SELECT *
                    FROM DependentsByDepartment
                    WHERE `Number of Dependents` IN (SELECT MAX(`Number of Dependents`) FROM DependentsByDepartment);'''

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]} Department: {record[1]} dependents")
    
    return

def get_hires_in_1997(mycursor):
    print("\nHires in 1997\n---------------------")
    #create query
    sql_query = 'SELECT * FROM HiresByYear WHERE year = 1997;'

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]}: {record[1]} employees hired")
    
    return

def get_finance_department_salary(mycursor):
    print("\nTotal Salary for the Finance Department\n---------------------")
    #create query
    sql_query = 'SELECT * FROM SalaryByDepartment WHERE department_name = "Finance";'

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]} Department: ${record[1]}")
    
    return

def get_job_title_largest_salary(mycursor):
    print("\nJob Title with the largest total salary\n---------------------")
    #create query
    sql_query = '''SELECT *
                    FROM SalaryByJobTitle
                    WHERE `Total Salary` IN (SELECT MAX(`Total Salary`) FROM SalaryByJobTitle);'''

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]}: ${record[1]}")
    
    return

def get_employees_no_dependents(mycursor):
    print("\nEmployees with No Dependents\n---------------------")
    #create query
    sql_query = 'SELECT * FROM EmployeeDependents WHERE `Number of Dependents` = 0;'

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]} {record[1]}: {record[4]} dependents")
    
    return

def get_countries_no_locations(mycursor):
    print("\nCountries with No Locations\n---------------------")
    #create query
    sql_query = 'SELECT * FROM CountryLocation WHERE `Number of Locations` = 0;'

    #execute the query
    mycursor.execute(sql_query)

    #get the query result
    query_result = mycursor.fetchall()

    #loop through results
    for record in query_result:
        print(f"{record[0]}: {record[1]} locations")
    
    return


def print_menu():
    print("\nChoose an option\n-----------------------")
    print("1. Show Number of Employees from the Americas")
    print("2. Show number of managers per department")
    print("3. Show department with the most dependents")
    print("4. Show number of hires in 1997")
    print("5. Show total salary for the Finance Department")
    print("6. Show job title with the largest salary")
    print("7. Show employees with no dependents")
    print("8. Show countries with no locations")
    print("9. Exit Application")
    return

def get_user_choice():
    print_menu()
    while(True):
        try:
            the_choice = int(input("Enter Choice: "))
            if(the_choice < 1 or the_choice > 9):
                print(f"Invalid input: Enter a value between 1 and 9.\n")
                continue
            break
        except Exception as err:
            print(f"An error has occured: {err}\n")
            continue

    return the_choice


def main():
#create a connector object
    try:
        mydb = mysql.connector.connect(
            host="mysql-container",
            user="root",
            passwd="root",
            database="finalproject"
        )
        print("Successfully connected to the database!")
    except Exception as err:
        print(f"Error Occured: {err}\nExiting program...")
        quit()

    #create database cursor
    mycursor = mydb.cursor()

    while(True):
        user_choice = get_user_choice()
        if(user_choice == 1):
            #call the function to query the managers
            get_americas_employees(mycursor)
        elif(user_choice == 2):
            get_mangers(mycursor)
        elif(user_choice == 3):
            get_department_most_dependents(mycursor)
        elif(user_choice == 4):
            get_hires_in_1997(mycursor)
        elif(user_choice == 5):
            get_finance_department_salary(mycursor)
        elif(user_choice == 6):
            get_job_title_largest_salary(mycursor)
        elif(user_choice == 7):
            get_employees_no_dependents(mycursor)
        elif(user_choice == 8):
            get_countries_no_locations(mycursor)
        elif(user_choice == 9):
            print("Bye Bye!!!")
            break

main()
    

