--1.  Write a query to create a view named “EmployeesPerRegion” that shows the region_name and the number of employees 
--from that region in a column called “Number of Employees”. 
CREATE VIEW EmployeesPerRegion AS
SELECT r.region_name, COUNT(e.employee_id) As "Number of Employees"
FROM employees e
JOIN departments d ON d.department_id = e.department_id
JOIN locations l ON l.location_id = d.location_id
JOIN countries c ON c.country_id = l.country_id
JOIN regions r ON r.region_id = c.region_id
GROUP BY r.region_id;

-- Query the EmployeesPerRegion to show the number of employees from the Americas.
SELECT * FROM EmployeesPerRegion
WHERE region_name = "Americas";

--2. Write a query to create a view named “managers” to display all the managers. 
--Include the manager’s name (first, last), phone number, email, job title, and department name. 
CREATE VIEW managers AS
SELECT e.first_name, e.last_name, e.phone_number, e.email, j.job_title, d.department_name
FROM employees e, departments d, jobs j
WHERE e.department_id = d.department_id AND e.job_id = j.job_id AND e.employee_id IN (SELECT manager_id from employees);


--Query the managers view to show the number of managers in each department.
SELECT department_name, COUNT(department_name) AS "Number of Managers"
FROM managers
GROUP BY department_name
ORDER BY COUNT(department_name) DESC;

--3. Write a query to create a view named “DependentsByDepartment” to get a count of how many dependents there are in each department.
CREATE VIEW DependentsByDepartment AS
SELECT d.department_name, COUNT(de.dependent_id) AS "Number of Dependents"
FROM dependents de
JOIN employees e ON e.employee_id = de.employee_id
JOIN departments d ON d.department_id = e.department_id
GROUP BY d.department_name
ORDER BY COUNT(de.dependent_id) DESC;


--Query the DependentsByDepartment view to show the department with the largest number of dependents. 
--This should show the department name and the number of dependents.
SELECT *
FROM DependentsByDepartment
WHERE `Number of Dependents` = (SELECT MAX(`Number of Dependents`) FROM DependentsByDepartment);


--4. Write a query to create a view named “HiresByYear” that calculates the number of employees hired each year. Remember the SQL $year function.
CREATE VIEW HiresByYear AS  
SELECT YEAR(hire_date) AS "year", COUNT(employee_id) AS "Employees Hired"
FROM employees
GROUP BY YEAR(hire_date);

-- Query the HiresByYear view to show the number of hires in 1997.
SELECT *
FROM HiresByYear
WHERE year = 1997;

--5. Write a query to create a view named “SalaryByDepartment” to calculate total salaries for each department. 
CREATE VIEW SalaryByDepartment AS
SELECT d.department_name, SUM(e.salary) AS "Total Salary"
FROM departments d, employees e
WHERE e.department_id = d.department_id
GROUP BY d.department_name
ORDER BY SUM(e.salary) DESC;

-- Query the SalaryByDepartment view to show the total salary for the Finance department.
SELECT * FROM SalaryByDepartment WHERE department_name = "Finance";

--6. Write a query to create a view named “SalaryByJobTitle” to calculate total salaries for each job title. 
CREATE VIEW SalaryByJobTitle AS
SELECT j.job_title, SUM(e.salary) AS "Total Salary"
FROM jobs j, employees e
WHERE e.job_id = j.job_id
GROUP BY j.job_title
ORDER BY SUM(e.salary) DESC;

--Query the SalaryByJobTitle view to show the job title and total salary for the title with the highest total salary.
SELECT *
FROM SalaryByJobTitle
WHERE `Total Salary` IN (SELECT MAX(`Total Salary`) FROM SalaryByJobTitle);

--7. Write a query to create a view named “EmployeeDependents” that calculates the number of dependents each employees has. 
--This query should show employees even if they have 0 dependents. 
--Display the employee name (first, last), email, phone number, and number of dependents. Hint: left or right join. 
CREATE VIEW EmployeeDependents AS
SELECT e.first_name, e.last_name, e.email, e.phone_number, COUNT(d.dependent_id) AS "Number of Dependents"
FROM employees e
LEFT JOIN dependents d ON d.employee_id = e.employee_id
GROUP BY e.employee_id;


--Query the EmployeeDependents view to show employees with no children". 
--Show employee name (first, last), email, phone number, and number of dependents.
SELECT * FROM EmployeeDependents WHERE `Number of Dependents` = 0;


--8. Write a query to create a view named “CountryLocation” that calculates the number of locations in each country. 
--This query should show countries even if they have 0 locations. Display the country name and number of locations. 
CREATE VIEW CountryLocation AS
SELECT c.country_name, COUNT(l.location_id) AS "Number of Locations"
FROM countries c
LEFT JOIN locations l ON c.country_id = l.country_id
GROUP BY c.country_name;

--Query the CountryLocation view to show countries with no locations". Show country name and number of locations.
SELECT * FROM CountryLocation WHERE `Number of Locations` = 0;

